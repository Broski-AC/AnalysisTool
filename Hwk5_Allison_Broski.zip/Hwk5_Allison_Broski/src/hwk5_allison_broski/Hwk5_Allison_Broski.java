/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hwk5_allison_broski;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Allison
 */
public class Hwk5_Allison_Broski {

    private static String answer;
    
    public static void main(String[] args) {
        
        //Prompt 4a - Create an array of the abstract class
        Generation[] RedandGreen = new Generation[4];
        //Fill the array with at least two instances of the child and grandchild 
        //classes
        RedandGreen[0] = new TypeGroup(1, "Kanto", "Fire", "Water", "Grass");
        RedandGreen[1] = new TypeGroup(1, "Kanto", "Water", "Grass", "Fire");
        RedandGreen[2] = new Pokemon(1, "Kanto", "Electric", "Ground", "Flying", 
                025, "Pikachu", "N/A");
        RedandGreen[3] = new Pokemon(1, "Kanto", "Ice", "Fire", "Grass", 144,
                "Articuno", "Flying");
        
        
        //Random generator for later, plus an array of types
        String[] types = {"Fire", "Water", "Grass", "Electric", "Ground", 
            "Flying", "Ice"};
        Random rnm = new Random();
        
        //Prompt 4b - Loop through the array usisg the instance of operator
        for (int i = 0; i < RedandGreen.length; i++)
        {
            if (RedandGreen[i] instanceof TypeGroup)
            {
                int randomType = rnm.nextInt(types.length);
                ((TypeGroup)RedandGreen[i]).compareTo(types[randomType]);
            }
            else
            {
                int randomType = rnm.nextInt(types.length);
                ((Pokemon)RedandGreen[i]).compareSecondType(types[randomType]);
            }
        }
        
        //Prompt 4c: Loop through our above array and printout the class name 
        //and toString for each object
        for (int i = 0; i < RedandGreen.length; i++)
        {
            Generation object = RedandGreen[i];
            System.out.println("The class is: " + object.getClass()
                    .getSimpleName());
            System.out.println(object.toString());
        }
        
        //Prompt 4d - Doing other things in the main to demonstrate inheritence 
        //and polymorphism
        //Creating a unique pokemon object
        System.out.println("\nWould you like to analyze your own Pokemon? "
                + "Please insert a 'Y' or 'N'");
        Scanner scan = new Scanner(System.in);
        answer = scan.nextLine();
        
        while (!answer.equalsIgnoreCase("Y")&&!answer.equalsIgnoreCase("N"))
        {
            System.out.println("Please insert a valid answer of either 'Y' or "
                    + "'N' (without the '')");
            answer = scan.nextLine(); 
        }
        
        if (answer.equalsIgnoreCase("Y"))
        {
          try
          {
            //Getting the various variables that will be necessary to create 
              //a unique Pokemon instance
            System.out.println("Please type in: \nThe generation number: ");
            int gen = scan.nextInt();
            scan.nextLine();
            System.out.println("\nThe region your Pokemon exists in: ");
            String region = scan.nextLine();
            System.out.println("\nThe Pokemon's primary type: ");
            String type = scan.nextLine();
            System.out.println("\nA type it is weak against: ");
            String weakness = scan.nextLine();
            System.out.println("\nA type it is strong against: ");
            String strength = scan.nextLine();
            System.out.println("\nIt's number in the National Pokedex "
                    + "(preceeded by a 0 if under 100)");
            int num = scan.nextInt();
            scan.nextLine();
            System.out.println("\nThe name of the Pokemon: ");
            String name = scan.nextLine();
            System.out.println("\nAny secondary type it may have. "
                    + "If none, please put in 'N/A': ");
            String secondType = scan.nextLine();
          
            //Instance creation
            Generation userEntry = new Pokemon(gen, region, type, weakness, 
                    strength, num, name, secondType);
        
            System.out.println(userEntry.toString());
            
            System.out.println("\nDid " + name + " have a place in the initial "
                    + "campaign in another generation? If so, please put in 'Y'"
                    + " or else respond with 'N'");
            String response = scan.nextLine();
            
            //Demonstations of inheritence by calling the setGen method in 
            //the Generation parent
            if (response.equals("Y"))
            {
                System.out.println("Please put in its second generation "
                        + "apperance");
                int nextgen = scan.nextInt();
                scan.nextLine();
                userEntry.setGen(nextgen);
            }
            else if (response.equals("N"))
            {
                System.out.println("\nThat's too bad. I'm sure that "
                        + "they would have been good.");
            }
            else 
            {
                System.out.println("\nPlease insert a valid "
                        + "answer of either 'Y' or 'N' (without the '')");
                response = scan.nextLine();
            }
           
            System.out.println("\nWe will now be conducting a "
                    + "secondary or primary-type match-up");
            
            //Demonstation of polymorphism by calling specific methods 
            //from subclasses of Generation
            if (secondType.equals("N/A"))
            {
                int randomType = rnm.nextInt(types.length);
                System.out.println("We'll be comparing the primary "
                        + "type of the Pokemon");
                ((TypeGroup)userEntry).compareTo(types[randomType]);
            }
            else
            {
                int randomType = rnm.nextInt(types.length);
                System.out.println("We'll be comparing the secondary types");
               ((Pokemon)userEntry).compareSecondType(types[randomType]);
            }
        }
          catch (Exception e)
          {
              System.out.println("The program has detected an error in "
                      + "your inputs. We apolize for the "
                      + "inconvience, but the program will now stop.");
              System.exit(0);
          }
        }  
        else
        {
            System.out.println("Thank you. Program ending...");
        }  
    }   
}
