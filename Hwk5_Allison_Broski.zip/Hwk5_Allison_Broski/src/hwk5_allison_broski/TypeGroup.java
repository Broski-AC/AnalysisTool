/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hwk5_allison_broski;

//Prompt 2 - Create a child class that extends the abstract superclass
public class TypeGroup extends Generation{
    
    //Prompt 2a - Add at least one extra data member to the child class
    //Determines which group is being discussed
    String primaryType;
    //Stores one of the traditional type weaknesses for the primaryType
    String basicWeakness;
    //Stores one of the traditional type strengths for the primaryType
    String basicStrength;
    
    //3D Array to hold type match-ups so that the system can be more dynamic
    String[][][] typeMatchUps= { 
        {
            //Main type
            {"Fire"},
            //Strengths
            {"Bug", "Steel", "Grass", "Ice"},
            //Weaknesses
            {"Rock", "Fire", "Water", "Dragon"}       
        },
        {
            {"Water"},
            {"Ground", "Rock", "Fire"},
            {"Water", "Grass", "Dragon"}
        },
        {
            {"Grass"},
            {"Ground", "Rock", "Water", "", "", "", ""},
            {"Flying", "Poison", "Bug", "Steel", "Fire", "Grass", "Dragon"}
        },
        {
            {"Electric"},
            {"Flying","Water", ""},
            {"Grass", "Electric", "Dragon"}
        },
        {
            {"Ground"},
            {"Poison", "Rock", "Steel", "Fire", "Electric"},
            {"Bug", "Grass", "", "", ""}
        },
        {
            {"Flying"},
            {"Fighting", "Bug", "Grass"},
            {"Rock", "Steel", "Electric"}
        },
        {
            {"Ice"},
            {"Flying", "Ground", "Grass", "Dragon"},
            {"Steel","Fire","Water","Ice"}
        }
    };
    
    //Prompt 2b - Create at least 1 constructor for the class
    public TypeGroup(int generation, String region,String primary, 
            String weakness, String strength){
        super(generation, region);
        primaryType = primary;
        basicWeakness = weakness;
        basicStrength = strength;
    }
    
    //Prompt 2c - Class methods
    
    //Set the primary type of the pokemon
    public void setType(String type){
        primaryType = type;
    }
    
    //Set the primary weakness of the pokemon
    public void setWeakness(String weak){
        basicWeakness = weak;
    }
    
    //Set a type that the pokemon is strong against
    public void setStrength(String strength){
        basicStrength = strength;
    }
    
    //Get the primary type of the pokemon
    public String getType(){
        return primaryType;
    }
    
    //Get a potential weakness of the pokemon
    public String getWeakness(){
        return basicWeakness;
    }

    //Get a potential strength of the pokemon
    public String getStrength(){
        return basicStrength;
    }
    
    //toString method
    public String toString()
    {    
        return super.toString() + 
                " Some Pokemon are of type " + primaryType + ". "
                + "They are weak to " + basicWeakness + " and are powerful "
                + "against " + basicStrength + ".\n";
    }

    //One new method - compareTo method mentioned in the main method
    //Compares the primary type of the pokemon against a random type 
    //determined in the main method class
    public void compareTo(String type){
        
            System.out.println("Please hold...");
            
            //Calls the searchType method (see below)
            String searchResult = searchType(type);
            if (searchResult.equals("Strength"))
            {
                //Using a data member of the Generation class in our output
                System.out.println("It is highly likely Pokemon of the " 
                        + primaryType + " type family will be able to beat "
                        + "Pokemon of type " + type + " in generation" 
                        + generation + "\n");
            }
            else if (searchResult.equals("Weakness"))
            {
                System.out.println("It is highly likely Pokemon of the " 
                        + primaryType + " type family will be defeated at the "
                        + "hands of a " + type + " type Pokemon in generation" 
                        + generation + ".\n");
            }
            else
            {
                System.out.println("It is impossible to tell whether "
                        + "Pokemon of the " + primaryType + " type family will "
                                + "be successful against"
                        + " those Pokemon in the " + type + 
                        " type family in generation " + generation + ".\n");
            }
        
    }
    
    //searchType method for use in the compareTo method
    //For use to suppliment the compareType method and determine 
    //whether the primary type will
     //Benefit or hinder a Pokemon
    public String searchType(String type){
        //Go through each 2D array in the 3D array
        for (String[][] typeName:typeMatchUps)
        {
            //Comparing the primaryTypes
            if (typeName[0][0].equalsIgnoreCase(primaryType))
            {
                
                for (int row = 1; row < typeName.length; row++)
                {
                    for (int col = 0; col < typeName[row].length; col++)
                    {
                        //Strength case
                        if (typeName[1][col].equalsIgnoreCase(type))
                        {
                            return "Strength";
                        }
                        //Weakness case
                        else if (typeName[2][col].equalsIgnoreCase(type))
                        {
                            return "Weakness";
                        }
                    }
                }
            }
            else
            {
                //Do nothing
            }     
        }
        //Returned everything I wanted to in the above stages, 
        //so this doesn't need to return anything
        return "";
    }

}
