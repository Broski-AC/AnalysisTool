/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hwk5_allison_broski;

//Prompt 1 - Create an abstract superclass
public abstract class Generation {
    //Prompt 1a -Define at least 2 data members that all child classes will have
    //int to hold which generation the pokemon are in
    int generation;
    //String to hold which region they belong to
    String region;
    
    //Prompt 1b - Create at least 1 Constructor for the class
    public Generation(int generation, String region){
        this.generation = generation;
        this.region = region;
    }
    
    //Prompt 1c - Write some class methods
    //set the generation of the pokemon
    public void setGen(int gen){
        generation = gen;
    }
    
    //get the generation the pokemon exists in
    public int getGen(){
        return generation;
    }
    
    //set the region the pokemon belongs in
    public void setRegion(String reg){
        region = reg;
    }
    
    //Get the region the pokemon belongs in
    public String getRegion(){
        return region;
    }
    
    //Required toString method
    public String toString(){
        return "\nCreatures from Gen " + generation + " live in the " + 
                region + " region.";
    }
    
}
