/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hwk5_allison_broski;

//Prompt 3 - Create a child class that extends the Parent class.
public class Pokemon extends TypeGroup {
    
    //Prompt 3a - Add at least one extra data member to the class
    int nationalNumber;
    String name;
    String secondaryType;
    
    //Prompt 3b - Create at least one constructor for the class
     public Pokemon(int generation, String region, String primary, 
             String weakness, String strength, int num, 
             String name, String secondType)
     {
         super(generation, region, primary, weakness, strength);
         nationalNumber = num;
         this.name = name;
         secondaryType = secondType;
     }
     
     //Prompt 3c - Class methods
     //Set the national number
     public void setNationalNum(int num){
         nationalNumber = num;
     }
     
     //Set the name of the Pokemon
     public void setName(String name){
         this.name = name;
     }
     
     //Set the secondary type of the Pokemon
     public void setSecondType(String type){
         secondaryType = type;
     }
     
     //Set the number of the Pokemon
     public int getNum(){
         return nationalNumber;
     }
     
     //Get the name of the Pokemon
     public String getName(){
         return name;
     }
     
     //Get the second type of the Pokemon
     public String getSecondType(){
         return secondaryType;
     }
     
     //toString method
     public String toString(){
         return super.toString() + "National Pokedex Number: " + 
                 nationalNumber + "\nName: " + name + "\nSecondary "
                 + "type (if any): " + secondaryType;
     }
    
     //One new method using parent and grandparent
     //Compares the secondary type of the Pokemon to some random type 
     //retrieved from the main method
     public void compareSecondType(String type){
             System.out.println("\nWe will be able to compare two types.");
             if (secondaryType.equals("N/A"))
             {
                 //Using a method in the parent class
                 super.compareTo(type);
             }
             else
             {
                 String supper = searchType(type);
                 if (supper.equals("Weakness"))
                 {
                     //Using grandparent variable in the resulting output string
                     System.out.println("\nIt is likely " + name + 
                             " will be evenly matched against " + type + 
                             " in the " + 
                             generation + ((generation >= 4) ? "th" : "") + 
                             " generation.\n");
                 }
                 else if (supper.equals("Strength"))
                 {
                     System.out.println("\nIt is likely " + name + 
                             " will be able to overcome a potential "
                                     + "weakness against " + type + 
                             " types in the " + generation 
                             + ((generation >= 4) ? "th" : "") + 
                             " generation.\n");
                 }
                 
                 else
                 {
                    System.out.println("\nIt is impossible to determine how "
                            + "" + name + "'s secondary type of " + 
                            secondaryType + " will affect"
                            + " it's performance against " + type + 
                            " type Pokemon in the " + generation + 
                            ((generation >= 4) ? "th" : "") + " generation.\n");
                 }
                 
             }
         }
        
     //For use to suppliment the compareSecondaryType method and determine 
     //whether the second type will potentially 
     //Benefit or hinder a Pokemon
     public String searchType(String type){
        //Go through each 2D array in the 3D array
        //Using an array in the parent class
        for (String[][] typeName:typeMatchUps)
        {
            if (typeName[0][0].equalsIgnoreCase(secondaryType))
            {
                
                for (int row = 1; row < typeName.length; row++)
                {
                    for (int col = 0; col < typeName[row].length; col++)
                    {
                        //Strength case
                        if (typeName[1][col].equalsIgnoreCase(type))
                        {
                            return "Strength";
                        }
                        //Weakness case
                        else if (typeName[2][col].equalsIgnoreCase(type))
                        {
                            return "Weakness";
                        }
                    }
                }
            }
            else
            {
                //Do nothing
            }     
        }
        return "";
    }
}

